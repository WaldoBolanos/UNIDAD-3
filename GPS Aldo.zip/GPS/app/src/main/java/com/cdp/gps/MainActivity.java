package com.cdp.gps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, GoogleMap.OnMapLongClickListener {

    EditText txtlatitud, txtlongitud;
    GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtlatitud = findViewById(R.id.txtlatitud);
        txtlongitud = findViewById(R.id.txtlongitud);

        SupportMapFragment mapFragment= (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap= googleMap;
        this.mMap.setOnMapClickListener(this);
        this.mMap.setOnMapLongClickListener(this);

        LatLng TecNMSJR = new LatLng(20.3729606,-99.9837465);
        mMap.addMarker(new MarkerOptions().position(TecNMSJR).title("Instituto Tecnologico De México, Campus San Juan Rio"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(TecNMSJR));
    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {
        txtlatitud.setText(""+latLng.longitude);
        txtlatitud.setText(""+latLng.latitude);

        mMap.clear();
        LatLng TecNMSJR = new LatLng(latLng.longitude,latLng.latitude);
        mMap.addMarker(new MarkerOptions().position(TecNMSJR).title(""));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(TecNMSJR));
    }

    @Override
    public void onMapLongClick(@NonNull LatLng latLng) {
        txtlatitud.setText(""+latLng.longitude);
        txtlatitud.setText(""+latLng.latitude);

        mMap.clear();
        LatLng TecNMSJR = new LatLng(latLng.longitude,latLng.latitude);
        mMap.addMarker(new MarkerOptions().position(TecNMSJR).title(""));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(TecNMSJR));
    }
}